# UCord Android — Build Guide
## متطلبات
- Android Studio (أحدث نسخة) أو Command Line Tools
- JDK 17+

## بناء الـ APK (Android Studio)
1. افتح Android Studio
2. اضغط "Open" واختر مجلد ucord_android
3. انتظر Gradle sync ينتهي
4. من القائمة العلوية: Build → Build Bundle(s) / APK(s) → Build APK(s)
5. الـ APK يكون في: app/build/outputs/apk/debug/app-debug.apk

## بناء الـ APK (Command Line)
```bash
cd ucord_android
./gradlew assembleDebug
```
الـ APK: app/build/outputs/apk/debug/app-debug.apk

## تثبيت مباشر
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

## ملاحظات
- الـ APK يفتح discord.com ويحقن المكسر تلقائياً
- سجّل دخولك بحسابك عادي
- المكسر يشتغل فور تحميل الصفحة
