package com.coza.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.*;
import android.view.View;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {

    private WebView webView;
    private ProgressBar progressBar;
    private String injectorJs;
    private String fakedeafenJs;
    private String gojoDataUri;
    private String pictureDataUri;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Full screen, keep screen on
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN |
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            WindowManager.LayoutParams.FLAG_FULLSCREEN |
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );

        // Load assets
        injectorJs    = loadAsset("ucore/injector.js");
        fakedeafenJs  = loadAsset("ucore/fakedeafen.js");
        gojoDataUri   = "data:image/gif;base64," + loadAssetBase64("ucore/gojo.gif");
        pictureDataUri = "data:image/jpeg;base64," + loadAssetBase64("ucore/picture.jpg");

        // Layout
        RelativeLayout root = new RelativeLayout(this);
        root.setBackgroundColor(0xFF000000);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setId(View.generateViewId());
        RelativeLayout.LayoutParams pbp = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.MATCH_PARENT, 8);
        pbp.addRule(RelativeLayout.ALIGN_PARENT_TOP);
        root.addView(progressBar, pbp);

        webView = new WebView(this);
        webView.setId(View.generateViewId());
        RelativeLayout.LayoutParams wvp = new RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.MATCH_PARENT,
            RelativeLayout.LayoutParams.MATCH_PARENT);
        wvp.addRule(RelativeLayout.BELOW, progressBar.getId());
        root.addView(webView, wvp);
        setContentView(root);

        // WebView settings
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setAllowFileAccess(false);
        ws.setAllowContentAccess(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        ws.setUserAgentString(
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Mobile Safari/537.36"
        );
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        ws.setSupportZoom(false);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);

        // Cookie
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new UCordBridge(), "UCordBridge");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                if (newProgress == 100) {
                    new Handler(Looper.getMainLooper()).postDelayed(
                        () -> progressBar.setVisibility(View.GONE), 400);
                } else {
                    progressBar.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public boolean onShowFileChooser(WebView wv, ValueCallback<Uri[]> cb,
                    FileChooserParams params) {
                // Allow file picker for uploads
                Intent intent = params.createIntent();
                try {
                    startActivityForResult(intent, 1001);
                } catch (Exception e) {
                    cb.onReceiveValue(null);
                }
                return true;
            }

            // Mic/camera permission
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                request.grant(request.getResources());
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (url != null && url.contains("discord.com")) {
                    injectUcore(view);
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                String u = req.getUrl().toString();
                if (u.contains("discord.com") || u.contains("discordapp.com")) {
                    return false; // load inside WebView
                }
                // Open external links in browser
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));
                } catch (Exception ignored) {}
                return true;
            }
        });

        webView.loadUrl("https://discord.com/app");
    }

    // ── Inject ucore ──────────────────────────────────────────────────────
    private void injectUcore(WebView view) {
        // Build the EXT_BASE stub and asset data URIs, then inject both scripts
        String bootstrap =
            "(function(){\n" +
            "  if(window.__N7RCORDV2_INJECTED__) return;\n" +
            // Provide gojo.gif and skin/picture.jpg as data URIs
            "  window.__UCORD_ASSETS__ = {\n" +
            "    'gojo.gif': " + jsStr(gojoDataUri) + ",\n" +
            "    'skin/picture.jpg': " + jsStr(pictureDataUri) + "\n" +
            "  };\n" +
            // Patch document.scripts so injector.js finds its own src
            "  var _origScripts = Object.getOwnPropertyDescriptor(Document.prototype,'scripts')\n" +
            "    || Object.getOwnPropertyDescriptor(HTMLDocument.prototype,'scripts');\n" +
            "  var _fakeBase = 'https://ucord-assets.local/';\n" +
            // Patch fetch so asset URLs resolve to data URIs
            "  var _realFetch = window.fetch;\n" +
            "  window.fetch = function(input, init) {\n" +
            "    var url = typeof input==='string'?input:(input&&input.url)||'';\n" +
            "    for(var k in window.__UCORD_ASSETS__) {\n" +
            "      if(url.indexOf(k)!==-1) {\n" +
            "        var da=window.__UCORD_ASSETS__[k];\n" +
            "        return Promise.resolve({\n" +
            "          ok:true, status:200,\n" +
            "          blob:function(){return fetch(da).then(function(r){return r.blob();})},\n" +
            "          text:function(){return Promise.resolve(da)},\n" +
            "          json:function(){return Promise.resolve(null)}\n" +
            "        });\n" +
            "      }\n" +
            "    }\n" +
            "    return _realFetch.apply(this,arguments);\n" +
            "  };\n" +
            // Inject fakedeafen first
            "  (function(){\n" + fakedeafenJs + "\n  })();\n" +
            // Then injector — with EXT_BASE pointing to fake base
            "  var _s=document.createElement('script');\n" +
            "  _s.textContent=(function(){\n" +
            "    var _code=" + jsStr(
                injectorJs.replace(
                    "for (const s of document.scripts) {\n                const src = s.src || '';\n                if (src.includes('injector.js'))\n                    return src.substring(0, src.lastIndexOf('/') + 1);",
                    "return 'https://ucord-assets.local/';"
                )
            ) + ";\n" +
            "    return _code;\n" +
            "  })();\n" +
            "  (document.head||document.documentElement).appendChild(_s);\n" +
            "})();";

        view.evaluateJavascript(bootstrap, null);
    }

    private static String jsStr(String s) {
        // Escape for JS string literal inside evaluateJavascript
        return "`" + s.replace("\\", "\\\\").replace("`", "\\`").replace("$", "\\$") + "`";
    }

    // ── Asset helpers ──────────────────────────────────────────────────────
    private String loadAsset(String path) {
        try (InputStream is = getAssets().open(path);
             BufferedReader r = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) { sb.append(line).append('\n'); }
            return sb.toString();
        } catch (IOException e) {
            return "/* asset load error: " + path + " */";
        }
    }

    private String loadAssetBase64(String path) {
        try (InputStream is = getAssets().open(path)) {
            byte[] data = new byte[is.available()];
            is.read(data);
            return android.util.Base64.encodeToString(data, android.util.Base64.NO_WRAP);
        } catch (IOException e) {
            return "";
        }
    }

    // ── Bridge (callable from JS if needed) ───────────────────────────────
    public class UCordBridge {
        @JavascriptInterface
        public String getVersion() { return "ucore-android-3.19.0"; }
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onDestroy() {
        webView.destroy();
        super.onDestroy();
    }
}
